/*
 * install.c - amipkg AmigaOS execution layer
 *
 * Executes a recipe plan (arun_plan) against a downloaded archive: unpack via
 * the mandatory C:lha, walk the extract tree, run the copy/set-exec/script-
 * inject ops with dos.library, and record the receipt. This is the on-Amiga
 * half of install - the portable half (arun_plan_build, host-tested) decided
 * WHAT to do; this does it.
 *
 * UNVERIFIED ON HARDWARE: written to the documented dos.library API; compile
 * with bebbo's amiga-gcc and validate on a networked image before release.
 * The script-inject marker grammar mirrors ScriptEditor
 * ("; <name> - Amiga Imager <ver> - BEGIN/END") so on-Amiga and build-time
 * edits are mutually idempotent/removable.
 */

#ifdef __amigaos__

#include "../core/arun.h"
#include "../core/arecipe.h"
#include "../core/sha256.h"
#include "../core/aver.h"
#include "../core/store.h"

#include <exec/execbase.h>
#include <proto/exec.h>
#include <proto/dos.h>
#include <dos/dos.h>
#include <dos/dosextens.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define AMIPKG_MARK_VER "amipkg"

/* Recursively collect the extract tree as relative paths (files + dirs), so
 * arun can match globs. Returns the count; fills entries[]/is_dir[] up to max
 * (caller owns the string storage in `pool`). */
static size_t walk_tree(const char *root, const char *rel,
                        char (*pool)[256], int *is_dir, size_t max, size_t count)
{
    BPTR lock;
    struct FileInfoBlock *fib;
    char path[256];

    if (rel[0]) snprintf(path, sizeof path, "%s/%s", root, rel);
    else        snprintf(path, sizeof path, "%s", root);

    lock = Lock(path, ACCESS_READ);
    if (!lock) return count;
    fib = (struct FileInfoBlock *)AllocDosObject(DOS_FIB, NULL);
    if (!fib) { UnLock(lock); return count; }

    if (Examine(lock, fib) && fib->fib_DirEntryType > 0) {
        while (ExNext(lock, fib)) {
            char childrel[256];
            int isdir = fib->fib_DirEntryType > 0;
            if (rel[0]) snprintf(childrel, sizeof childrel, "%s/%s", rel, fib->fib_FileName);
            else        snprintf(childrel, sizeof childrel, "%s", fib->fib_FileName);
            if (count < max) {
                strncpy(pool[count], childrel, 255); pool[count][255] = 0;
                is_dir[count] = isdir;
                count++;
            }
            if (isdir) count = walk_tree(root, childrel, pool, is_dir, max, count);
        }
    }
    FreeDosObject(DOS_FIB, fib);
    UnLock(lock);
    return count;
}

/* Copy one file, creating parent drawers. dst is a full DOS path. */
static int copy_file(const char *src, const char *dst)
{
    BPTR in, out;
    static char buf[8192];
    LONG n;
    /* Ensure the parent drawer chain exists. */
    {
        char parent[256]; char *slash;
        strncpy(parent, dst, sizeof parent - 1); parent[sizeof parent - 1] = 0;
        slash = parent;
        while ((slash = strchr(slash + 1, '/')) != NULL) {
            char save = *slash; *slash = 0;
            { BPTR l = Lock(parent, ACCESS_READ); if (l) UnLock(l); else { BPTR d = CreateDir(parent); if (d) UnLock(d); } }
            *slash = save;
        }
    }
    in = Open(src, MODE_OLDFILE);
    if (!in) return 0;
    out = Open(dst, MODE_NEWFILE);
    if (!out) { Close(in); return 0; }
    while ((n = Read(in, buf, sizeof buf)) > 0) Write(out, buf, n);
    Close(out); Close(in);
    return 1;
}

/* Ensure every parent drawer of `path` exists (mirror of copy_file's chain). */
static void ensure_parents(const char *path)
{
    char parent[256], *slash;
    strncpy(parent, path, sizeof parent - 1); parent[sizeof parent - 1] = 0;
    slash = parent;
    while ((slash = strchr(slash + 1, '/')) != NULL) {
        char save = *slash; *slash = 0;
        { BPTR l = Lock(parent, ACCESS_READ); if (l) UnLock(l);
          else { BPTR d = CreateDir(parent); if (d) UnLock(d); } }
        *slash = save;
    }
}

/* drawerIcon: install a standard Workbench drawer .info at `dst`. Read the
 * system default drawer icon (ENVARC:Sys/def_drawer.info, else the archive
 * fallback `fb`), force do_Type=WBDRAWER(2) and NO_ICON_POSITION, write it out.
 * Byte-for-byte mirror of AminetExplicitInstallers.drawerIcon + IconPatcher:
 * a DiskObject is do_Magic(0xE310)@0x00, do_Type@0x30, do_CurrentX/Y@0x3A/0x3E.
 * (Icon position is runtime-owned - Workbench rewrites it - so NO_ICON_POSITION
 * is the faithful build value; the golden harness masks it either way.) */
static int drawer_icon_write(const char *fb, const char *dst)
{
    static unsigned char ic[8192];
    BPTR in, out;
    LONG n;
    in = Open((STRPTR)"ENVARC:Sys/def_drawer.info", MODE_OLDFILE);
    if (!in && fb && fb[0]) in = Open((STRPTR)fb, MODE_OLDFILE);
    if (!in) return 0;
    n = Read(in, ic, sizeof ic);
    Close(in);
    if (n < 0x42 || ic[0] != 0xE3 || ic[1] != 0x10) return 0;   /* not a DiskObject */
    ic[0x30] = 0x02;                                            /* do_Type = WBDRAWER */
    ic[0x3A] = 0x80; ic[0x3B] = ic[0x3C] = ic[0x3D] = 0x00;     /* do_CurrentX = NO_ICON_POSITION */
    ic[0x3E] = 0x80; ic[0x3F] = ic[0x40] = ic[0x41] = 0x00;     /* do_CurrentY = NO_ICON_POSITION */
    ensure_parents(dst);
    out = Open((STRPTR)dst, MODE_NEWFILE);
    if (!out) return 0;
    Write(out, ic, n);
    Close(out);
    return 1;
}

/* Forward declarations - shared walk buffer + helpers defined further down
 * (tentative array declarations merge with the commented definitions). */
static char g_walk_pool[ARUN_MAX_OPS][256];
static int  g_walk_isdir[ARUN_MAX_OPS];
static const char *selfupdate_basename(const char *path);
static int ci_eq(const char *a, const char *b);

/* SetProtection: give a path the script (s) bit, clearing (e) is not needed -
 * matches copyFromHost's "0x40 script bit for exec files" for a script. The
 * plan's SET_EXEC scope maps to a subtree; we set the s-bit on plain files
 * there. NOTE: build parity keeps binaries WITHOUT the s-bit; a full port
 * should mirror isBinaryLoadFile. v0.1 sets the s-bit on shell scripts only
 * (files whose first two bytes aren't a hunk/ELF magic). */
static void set_script_bit_if_script(const char *path)
{
    BPTR fh = Open(path, MODE_OLDFILE);
    unsigned char magic[4];
    LONG n;
    if (!fh) return;
    n = Read(fh, magic, 4);
    Close(fh);
    if (n >= 4) {
        /* 0x000003F3 = AmigaDOS hunk; 0x7F 'E' 'L' 'F' = ELF. Skip those. */
        if (magic[0] == 0 && magic[1] == 0 && magic[2] == 3 && magic[3] == 0xF3) return;
        if (magic[0] == 0x7F && magic[1] == 'E' && magic[2] == 'L' && magic[3] == 'F') return;
    }
    SetProtection((STRPTR)path, FIBF_SCRIPT);   /* active-low semantics handled by dos */
}

/* Append an overlay into a boot script with the ScriptEditor BEGIN/END markers,
 * idempotently (skip if the marker is already present). */
static int inject_script(const char *script_path, const char *overlay_path, const char *marker)
{
    static char cur[16384], overlay[8192], begin[128], endm[128];
    BPTR fh; LONG n; size_t curlen = 0;

    snprintf(begin, sizeof begin, "; %s - Amiga Imager %s - BEGIN", marker, AMIPKG_MARK_VER);
    snprintf(endm, sizeof endm, "; %s - Amiga Imager %s - END", marker, AMIPKG_MARK_VER);

    fh = Open(script_path, MODE_OLDFILE);
    if (fh) {
        n = Read(fh, cur, sizeof cur - 1);
        Close(fh);
        if (n > 0) curlen = (size_t)n;
    }
    cur[curlen] = 0;
    if (strstr(cur, begin)) return 1;   /* already injected */

    fh = Open(overlay_path, MODE_OLDFILE);
    if (!fh) return 0;
    n = Read(fh, overlay, sizeof overlay - 1);
    Close(fh);
    if (n < 0) return 0;
    overlay[n > 0 ? n : 0] = 0;

    fh = Open(script_path, MODE_NEWFILE);
    if (!fh) return 0;
    if (curlen) Write(fh, cur, curlen);
    Write(fh, (APTR)"\n", 1);
    Write(fh, begin, strlen(begin)); Write(fh, (APTR)"\nFAILAT 30\n", 11);
    Write(fh, overlay, strlen(overlay));
    Write(fh, (APTR)"\nFAILAT 21\n", 11);
    Write(fh, endm, strlen(endm)); Write(fh, (APTR)"\n", 1);
    Close(fh);
    return 1;
}

/* Create a single drawer if it doesn't already exist (idempotent). */
static void ensure_one(const char *path)
{
    BPTR l = Lock((STRPTR)path, ACCESS_READ);
    if (l) { UnLock(l); return; }
    { BPTR d = CreateDir((STRPTR)path); if (d) UnLock(d); }
}

/* Create one drawer if it is missing (multi-repo: repos/ and repos/<id>/ are
 * made on demand when a repository is first updated). */
void amipkg_make_dir(const char *path) { ensure_one(path); }

/* Make sure amipkg's working drawers exist before we write to them. The
 * AMIPKG: assign exists after the bridge, but its cache/ and db/ sub-
 * drawers are not guaranteed present on every image - create them here so a
 * fetch/install never fails on a missing directory. */
/* Self-seed the amipkg receipt: `check`/`upgrade` only manage what the
 * receipt DB records, and skip-Install users (extract & start - the
 * blessed flow since 0.4.5) had NO amipkg entry, so self-update looked
 * "up to date" forever (tester report). Runs on every CLI start: appends
 * the entry when missing, bumps it when this binary is NEWER than the
 * recorded version (manual updates). Never touches files. */
/* Write amipkg's own file inventory, ABSOLUTELY.
 *
 * This used to record "PROGDIR:amipkg" and friends. A receipt outlives the
 * process that wrote it, and PROGDIR: is per-process: read back by a LATER
 * amipkg (the CLI the GUI shells out to, say), those lines resolve against
 * THAT program's drawer. Since an upgrade deletes the recorded paths, a
 * receipt seeded in one drawer could delete the app in another - a running
 * GUI erased from under itself (A4000 report, 2026-07-30). The prefix is
 * already absolute for exactly this reason (see amipkg_prefix) - the receipt
 * has to be too, and it is the prefix the recipe installs into, so the two
 * now describe the same files by the same names. */
static void seed_amipkg_file_inventory(void)
{
    static const char *bins[] = { "amipkg", "amipkg-gui", "amipkg-gui.info",
                                  "amipkg-mui", "amipkg-mui.info", "amipkg.guide", 0 };
    char probe[AMIPKG_PREFIX_MAX + 32];
    FILE *f = fopen(amipkg_data_path("db/files/amipkg.files"), "w");
    size_t i;
    if (!f) return;
    for (i = 0; bins[i]; i++) {
        BPTR l;
        snprintf(probe, sizeof probe, "%s%s", amipkg_prefix(), bins[i]);
        l = Lock((STRPTR)probe, ACCESS_READ);
        if (l) { UnLock(l); fprintf(f, "%s\n", probe); }
    }
    fclose(f);
}

/* Repair an inventory seeded by an older amipkg: any PROGDIR:-relative line is
 * a live hazard on every machine that already has one, so rewrite the whole
 * file from the resolved prefix. Cheap, idempotent, and runs before anything
 * can act on those paths. */
static void migrate_progdir_inventory(void)
{
    char rp[AMIPKG_PREFIX_MAX + 32], ln[400];
    FILE *f;
    int poisoned = 0;
    snprintf(rp, sizeof rp, "%sdb/files/amipkg.files", amipkg_prefix());
    f = fopen(rp, "r");
    if (!f) return;
    while (fgets(ln, sizeof ln, f))
        if (strncmp(ln, "PROGDIR:", 8) == 0) { poisoned = 1; break; }
    fclose(f);
    if (poisoned) seed_amipkg_file_inventory();
}

static void selfseed_receipt(void)
{
    rcpt_installed *inst = amipkg_inst_scratch;   /* shared scratch, see store.h */
    size_t n = load_installed(inst, MAX_PKGS), i;
    long have = -1;
    for (i = 0; i < n; i++)
        if (strcmp(inst[i].id, "amipkg") == 0) { have = (long)i; break; }
    /* Sync BOTH ways: the receipt must describe the amipkg the user RUNS.
     * Before 0.5.6 it only bumped upward - an upgrade whose new binaries
     * didn't reach the launch location left the receipt claiming the new
     * version, so every further check said "up to date" while the user
     * kept running the old one (A4000 report). If the receipt and this
     * binary disagree IN EITHER DIRECTION, rewrite it to this binary's
     * version - check/upgrade then re-offer the update and the self-update
     * mirror gets another chance to converge. */
    if (have >= 0 && strcmp(inst[have].version, AMIPKG_VERSION) == 0)
        return;
    if (have < 0) {
        FILE *f = fopen(amipkg_data_path("db/installed.txt"), "a");
        if (f) { fprintf(f, "amipkg|%s|1|0\n", AMIPKG_VERSION); fclose(f); }
        seed_amipkg_file_inventory();
    } else {
        /* Receipt disagrees with this binary (either direction): rewrite. */
        FILE *f = fopen(amipkg_data_path("db/installed.txt"), "wb");
        char line[192];
        if (!f) return;
        for (i = 0; i < n; i++) {
            if (strcmp(inst[i].id, "amipkg") == 0)
                strncpy(inst[i].version, AMIPKG_VERSION, sizeof inst[i].version - 1);
            rcpt_format_installed_line(&inst[i], line, sizeof line);
            fprintf(f, "%s\n", line);
        }
        fclose(f);
    }
}

void amipkg_ensure_dirs(void)
{
    amipkg_bridge_assigns();
    ensure_one(amipkg_data_path("cache"));
    ensure_one(amipkg_data_path("config"));
    ensure_one(amipkg_data_path("db"));
    ensure_one(amipkg_data_path("db/files"));
    ensure_one(amipkg_data_path("db/scripts"));
    ensure_one(amipkg_data_path("db/assigns"));
    migrate_progdir_inventory();   /* before anything can act on those paths */
    selfseed_receipt();
}

/* Free bytes on the volume holding `path` (e.g. "SYS:" / "AMIPKG:cache/").
 * -1 when unknown (RAM: and odd handlers) - callers must not block on that. */
long long amipkg_volume_free(const char *path)
{
    struct InfoData *info;
    BPTR lock;
    long long freeb = -1;
    lock = Lock((STRPTR)path, ACCESS_READ);
    if (!lock) return -1;
    info = (struct InfoData *)AllocDosObject(DOS_FIB, NULL);   /* FIB-sized+ */
    if (info) {
        /* InfoData fits in a FileInfoBlock allocation (260 bytes vs 36). */
        if (Info(lock, info))
            freeb = (long long)(info->id_NumBlocks - info->id_NumBlocksUsed)
                    * info->id_BytesPerBlock;
        FreeDosObject(DOS_FIB, info);
    }
    UnLock(lock);
    return freeb;
}

/* The running Kickstart's exec version (37=2.04, 39=3.0, 40=3.1, 44=3.5,
 * 45=3.9, 46=3.1.4, 47=3.2) for requirements.minKS enforcement. */
int amipkg_ks_version(void)
{
    return (int)SysBase->LibNode.lib_Version;
}

/* The running machine's CPU class, for dependency CPU-variant selection
 * (e.g. the 020 vs 68k build of an MUI class). From exec's AttnFlags. */
const char *amipkg_cpu(void)
{
    UWORD f = SysBase->AttnFlags;
    if (f & AFF_68060) return "68060";
    if (f & AFF_68040) return "68040";
    if (f & AFF_68030) return "68030";
    if (f & AFF_68020) return "68020";
    return "68000";
}

/* `amipkg adopt`: inventory an EXISTING drawer into files/<id>.files (path +
 * SHA-256 per file, like a normal install's receipt) so remove/doctor/upgrade
 * manage an app the user already had. Returns the file count. */
/* Is this drawer-relative path part of amipkg's OWN runtime state? Adopting
 * amipkg at its home drawer must NEVER inventory cache/db/config/catalog/
 * trace files: the upgrade's remove-previous step would otherwise delete the
 * receipt DB, the freshly extracted files in cache/extract, and the catalog
 * itself mid-upgrade (A4000 incident: "Removed amipkg: 57 file(s)" followed
 * by "nothing installed"). */
static int is_amipkg_runtime_rel(const char *rel)
{
    static const char *dirs[] = { "cache", "db", "config", NULL };
    size_t k, len;
    const char *base = selfupdate_basename(rel);
    for (k = 0; dirs[k]; k++) {
        len = strlen(dirs[k]);
        if (strlen(rel) >= len) {
            size_t x; int eq = 1;
            for (x = 0; x < len; x++) {
                int ca = tolower((unsigned char)rel[x]);
                int cb = tolower((unsigned char)dirs[k][x]);
                if (ca != cb) { eq = 0; break; }
            }
            if (eq && (rel[len] == '\0' || rel[len] == '/')) return 1;
        }
    }
    len = strlen(base);
    if (len > 6 && ci_eq(base + len - 6, ".trace")) return 1;
    if (ci_eq(base, "packages.json") || ci_eq(base, "packages.json.sig")) return 1;
    return 0;
}

static int has_suffix_ci(const char *s, const char *suf)
{
    size_t ls = strlen(s), lf = strlen(suf);
    if (lf > ls) return 0;
    return ci_eq(s + ls - lf, suf);
}

static int ci_contains(const char *hay, const char *needle)
{
    size_t i, j;
    if (!hay || !needle || !needle[0]) return 0;
    for (i = 0; hay[i]; i++) {
        for (j = 0; needle[j]; j++) {
            int a = hay[i + j], b = needle[j];
            if (a >= 'A' && a <= 'Z') a += 32;
            if (b >= 'A' && b <= 'Z') b += 32;
            if (!hay[i + j] || a != b) break;
        }
        if (!needle[j]) return 1;
    }
    return 0;
}

/* Read a "$VER: <name> <version> ..." string out of an Amiga binary.
 *
 * Every well-behaved Amiga executable carries one - it is what C:Version
 * reports. Scanned in blocks with a small overlap so a tag straddling a block
 * boundary is still found. Returns 1 and fills out/name_out on success. */
static int ver_from_file(const char *path, char *out, size_t n,
                         char *name_out, size_t name_n)
{
    FILE *f = fopen(path, "rb");
    static char buf[8192 + 64];
    size_t got, keep = 0;
    int found = 0;
    if (!f) return 0;
    while (!found && (got = fread(buf + keep, 1, 8192, f)) > 0) {
        size_t total = keep + got, i;
        buf[total] = '\0';
        for (i = 0; i + 6 < total; i++) {
            if (buf[i] == '$' && strncmp(buf + i, "$VER:", 5) == 0) {
                const char *p = buf + i + 5;
                const char *end = buf + total;
                char nm[64]; size_t k = 0;
                while (p < end && (*p == ' ' || *p == '\t')) p++;
                while (p < end && *p > ' ' && k < sizeof nm - 1) nm[k++] = *p++;
                nm[k] = '\0';
                while (p < end && (*p == ' ' || *p == '\t')) p++;
                k = 0;
                /* The version token: digits/dots, as C:Version prints it. */
                if (p < end && *p >= '0' && *p <= '9') {
                    while (p < end && *p > ' ' && k < n - 1) out[k++] = *p++;
                    out[k] = '\0';
                    if (k) {
                        strncpy(name_out, nm, name_n - 1);
                        name_out[name_n - 1] = '\0';
                        found = 1;
                    }
                }
                if (found) break;
            }
        }
        if (found) break;
        /* keep a tail so a tag split across reads is not missed */
        keep = (total > 32) ? 32 : total;
        memmove(buf, buf + total - keep, keep);
    }
    fclose(f);
    return found;
}

/* Detect the version actually installed in `drawer`.
 *
 * Testers adopt existing installs without knowing the version, and recording
 * "-" made the GUIs fall back to showing the CATALOG's version - which looks
 * like the real one until you disable the repo and it vanishes (djbase,
 * 2026-07-29). Reading the binary is what C:Version does, so it reports what
 * is genuinely on disk.
 *
 * A $VER whose name matches the package id (or the drawer's own name) wins;
 * otherwise the first one found is used. Returns 1 on success. */
int amipkg_detect_version(const char *drawer, const char *id, char *out, size_t n)
{
    char (*pool)[256] = g_walk_pool;
    int *is_dir = g_walk_isdir;
    size_t cnt, i;
    char best[48] = "", first[48] = "";
    const char *leaf;

    if (!out || n == 0) return 0;
    out[0] = '\0';
    leaf = strrchr(drawer, '/');
    leaf = leaf ? leaf + 1 : drawer;

    cnt = walk_tree(drawer, "", pool, is_dir, ARUN_MAX_OPS, 0);
    for (i = 0; i < cnt && !best[0]; i++) {
        char full[512], v[48], nm[64];
        const char *sep = drawer[strlen(drawer) - 1] == ':' ? "" : "/";
        const char *base;
        if (is_dir[i]) continue;
        base = strrchr(pool[i], '/');
        base = base ? base + 1 : pool[i];
        /* Skip the obvious non-programs. .library and .device DO carry a
         * $VER and are worth reading. */
        if (has_suffix_ci(base, ".readme") || has_suffix_ci(base, ".guide")
            || has_suffix_ci(base, ".info") || has_suffix_ci(base, ".txt")
            || has_suffix_ci(base, ".doc")  || has_suffix_ci(base, ".lha"))
            continue;
        snprintf(full, sizeof full, "%s%s%s", drawer, sep, pool[i]);
        if (!ver_from_file(full, v, sizeof v, nm, sizeof nm)) continue;
        if (!first[0]) { strncpy(first, v, sizeof first - 1); first[sizeof first - 1] = 0; }
        /* Prefer the tag that names this package. */
        if (ci_contains(nm, id) || ci_contains(nm, leaf) || ci_contains(base, nm)) {
            strncpy(best, v, sizeof best - 1); best[sizeof best - 1] = 0;
        }
    }
    if (!best[0] && first[0]) strncpy(best, first, sizeof best - 1);
    if (!best[0]) return 0;
    strncpy(out, best, n - 1); out[n - 1] = '\0';
    return 1;
}

long amipkg_adopt_inventory(const char *id, const char *drawer)
{
    char (*pool)[256] = g_walk_pool;
    int *is_dir = g_walk_isdir;
    size_t n, i;
    long files = 0;
    char rp[192];
    FILE *f;
    n = walk_tree(drawer, "", pool, is_dir, ARUN_MAX_OPS, 0);
    snprintf(rp, sizeof rp, "%sdb/files/%s.files", amipkg_prefix(), id);
    f = fopen(rp, "w");
    if (!f) return -1;
    for (i = 0; i < n; i++) {
        char full[512], hex[65];
        const char *sep = drawer[strlen(drawer) - 1] == ':' ? "" : "/";
        if (is_dir[i]) continue;
        if (ci_eq(id, "amipkg") && is_amipkg_runtime_rel(pool[i])) continue;
        snprintf(full, sizeof full, "%s%s%s", drawer, sep, pool[i]);
        if (sha256_of_file(full, hex) == 0) fprintf(f, "%s|%s\n", full, hex);
        else                                fprintf(f, "%s\n", full);
        files++;
    }
    fclose(f);
    return files;
}

/* Rename within a volume via dos.library (newlib's rename() pulls a missing
 * _link syscall on this toolchain). 0 on success. */
int amipkg_rename(const char *from, const char *to)
{
    return Rename((STRPTR)from, (STRPTR)to) ? 0 : 1;
}

/* Platform hook for the portable ADF reader (adfread.c): create one drawer. */
int adf_mkdir(const char *path)
{
    BPTR l = Lock((STRPTR)path, ACCESS_READ);
    if (l) { UnLock(l); return 0; }
    { BPTR d = CreateDir((STRPTR)path); if (d) { UnLock(d); return 0; } }
    return 1;
}

/* Strip one ScriptEditor overlay block ("; <marker> - Amiga Imager <any> -
 * BEGIN" .. "- END", inclusive) from a boot script. The version token varies
 * ("0.99", "amipkg", "host"), so match the stable prefix + BEGIN/END suffix.
 * Returns 1 stripped, 0 marker not found, -1 error. */
int amipkg_strip_overlay(const char *script_path, const char *marker)
{
    static char cur[16384], out[16384], prefix[96];
    BPTR fh;
    LONG n;
    size_t used = 0, o = 0;
    int in_block = 0, stripped = 0;
    char *line, *next;

    snprintf(prefix, sizeof prefix, "; %s - Amiga Imager ", marker);
    fh = Open((STRPTR)script_path, MODE_OLDFILE);
    if (!fh) return 0;
    n = Read(fh, cur, sizeof cur - 1);
    Close(fh);
    if (n <= 0) return 0;
    used = (size_t)n;
    cur[used] = '\0';
    if (!strstr(cur, prefix)) return 0;   /* nothing of ours in there */

    for (line = cur; line; line = next) {
        size_t len;
        char *nl = strchr(line, '\n');
        next = nl ? nl + 1 : NULL;
        len = nl ? (size_t)(nl - line) + 1 : strlen(line);
        if (!in_block && strncmp(line, prefix, strlen(prefix)) == 0
            && memchr(line, 'B', len) && strstr(line, "- BEGIN")
            && (strstr(line, "- BEGIN") < line + len)) {
            in_block = 1;
            stripped = 1;
            continue;                      /* drop the BEGIN line */
        }
        if (in_block) {
            if (strncmp(line, prefix, strlen(prefix)) == 0
                && strstr(line, "- END") && (strstr(line, "- END") < line + len))
                in_block = 0;              /* drop the END line, block done */
            continue;                      /* drop block content */
        }
        if (o + len < sizeof out) { memcpy(out + o, line, len); o += len; }
    }
    if (!stripped) return 0;

    fh = Open((STRPTR)script_path, MODE_NEWFILE);
    if (!fh) return -1;
    if (o) Write(fh, out, (LONG)o);
    Close(fh);
    return 1;
}

/* Unpack `archive` into `destdir` via C:lha (mandatory on every image). */
int amipkg_extract(const char *archive, const char *destdir)
{
    char cmd[512];
    LONG rc;
    { BPTR d = Lock(destdir, ACCESS_READ); if (d) UnLock(d); else { BPTR c = CreateDir(destdir); if (c) UnLock(c); } }
    snprintf(cmd, sizeof cmd, "C:lha -q x \"%s\" \"%s/\"", archive, destdir);
    rc = SystemTags(cmd, TAG_DONE);
    return rc == 0;
}

/* Execute `plan` against the extract dir, writing into the volume relative to
 * boot_root (e.g. "DH0:"). Returns the number of files written; fills
 * out_paths[] with the absolute installed paths for the receipt (up to max). */
size_t amipkg_execute(const arun_plan *plan, const char *extract_dir,
                      const char *boot_root, char (*out_paths)[256], size_t max)
{
    size_t i, written = 0;
    for (i = 0; i < plan->count; i++) {
        const arun_op *op = &plan->ops[i];
        char src[512], dst[512];
        switch (op->kind) {
        case ARUN_COPY: {
            /* A dest carrying an assign/volume (":" anywhere) is ABSOLUTE -
             * e.g. "AMIPKG:amipkg" (self-update into the home drawer);
             * everything else stays boot_root-relative. */
            const char *root = strchr(op->dest, ':') ? "" : boot_root;
            const char *destp = op->dest;
            char xlat[300];
            /* "AMIPKG:x" is a NAMESPACE for "amipkg's home", not a literal
             * assign - translate it to the runtime prefix (PROGDIR: on
             * standalone installs, where no assign exists at all). */
            if (strncmp(destp, "AMIPKG:", 7) == 0) {
                snprintf(xlat, sizeof xlat, "%s%s", amipkg_prefix(), destp + 7);
                destp = xlat;
            }
            snprintf(src, sizeof src, "%s/%s", extract_dir, op->src);
            snprintf(dst, sizeof dst, "%s%s", root, destp);
            if (copy_file(src, dst) && written < max) {
                snprintf(out_paths[written], 256, "%s%s", root, destp);
                written++;
            }
            break;
        }
        case ARUN_SET_EXEC:
            /* Best-effort: set the script bit on shell scripts in the scope.
             * A full port walks the scope subtree; v0.1 relies on lha having
             * preserved protection bits and only fixes obvious scripts. */
            break;
        case ARUN_SCRIPT:
            snprintf(src, sizeof src, "%s/%s", extract_dir, op->overlay);
            snprintf(dst, sizeof dst, "%s%s", boot_root, op->dest[0] == 'S' ? "S/User-Startup" : op->dest);
            (void)inject_script(dst, src, op->marker);
            break;
        case ARUN_STRIP:
            break;
        case ARUN_DRAWER_ICON: {
            /* dest is boot_root-relative (a normal package path); src is the
             * archive-relative fallback icon, joined onto extract_dir. */
            const char *root = strchr(op->dest, ':') ? "" : boot_root;
            char fb[512];
            snprintf(fb, sizeof fb, "%s/%s", extract_dir, op->src);
            snprintf(dst, sizeof dst, "%s%s", root, op->dest);
            if (drawer_icon_write(op->src[0] ? fb : "", dst) && written < max) {
                snprintf(out_paths[written], 256, "%s%s", root, op->dest);
                written++;
            }
            break;
        }
        }
    }
    (void)set_script_bit_if_script;   /* reserved for the full set-exec port */
    return written;
}

/* Execute one inline pre/post-install script: FailAt header + the recipe's
 * lines, via Execute of a RAM: file. Returns the script's worst return code.
 * The lines were REVIEWED into the signed catalog (pre-post-script-v1) -
 * this is curated native code, same trust rung as the Installer hatch. */
long amipkg_run_inline_script(const char *script, const char *label)
{
    BPTR fh;
    long rc;
    fh = Open((STRPTR)"RAM:amipkg-op.script", MODE_NEWFILE);
    if (!fh) { Printf((STRPTR)"amipkg: cannot write %s script\n", (LONG)label); return 10; }
    Write(fh, (APTR)"FailAt 21\n", 10);
    Write(fh, (APTR)script, (LONG)strlen(script));
    Write(fh, (APTR)"\n", 1);
    Close(fh);
    rc = SystemTags((STRPTR)"Execute RAM:amipkg-op.script", TAG_DONE);
    DeleteFile((STRPTR)"RAM:amipkg-op.script");
    return rc;
}

/* Full on-Amiga recipe run: pre-install scripts, then walk the extract tree,
 * build the plan (portable), execute it, then post-install scripts. Returns
 * the installed-file count, or 0 on plan failure / a failing pre-script. */
size_t amipkg_run_recipe(const arecipe *recipe, const char *extract_dir,
                         const char *boot_root, char (*out_paths)[256], size_t max)
{
    static char pool[ARUN_MAX_OPS][256];
    static int is_dir[ARUN_MAX_OPS];
    static const char *entries[ARUN_MAX_OPS];
    static arun_plan plan;   /* ~362 KB - MUST be static, not on the 4 KB Shell stack */
    size_t n, i, written;

    /* Pre-install scripts: a failure (rc >= 10) ABORTS the install - they
     * guard preconditions (stop a running instance, make an assign). */
    for (i = 0; i < recipe->op_count; i++) {
        if (recipe->ops[i].type != AROP_PRE_SCRIPT) continue;
        if (amipkg_run_inline_script(recipe->ops[i].script, "pre-install") >= 10) {
            PutStr((STRPTR)"amipkg: pre-install script failed - aborting.\n");
            return 0;
        }
    }

    n = walk_tree(extract_dir, "", pool, is_dir, ARUN_MAX_OPS, 0);
    for (i = 0; i < n; i++) entries[i] = pool[i];
    if (arun_plan_build(recipe, entries, is_dir, n, &plan) != 0 || plan.overflow)
        return 0;
    written = amipkg_execute(&plan, extract_dir, boot_root, out_paths, max);

    /* Post-install scripts: tidy-ups (ENVARC defaults, obsolete-file removal).
     * A failure here is a WARNING - the files are already placed. */
    if (written > 0) {
        for (i = 0; i < recipe->op_count; i++) {
            if (recipe->ops[i].type != AROP_POST_SCRIPT) continue;
            if (amipkg_run_inline_script(recipe->ops[i].script, "post-install") >= 10)
                PutStr((STRPTR)"amipkg: WARNING - a post-install script failed.\n");
        }
    }
    return written;
}

/* Does the extract tree consist of ONE top-level drawer (all entries share a
 * single first path component that is a directory)? Then the archive brings
 * its own app drawer and may land in the install dir as-is. Anything else
 * (flat archives, multiple roots, a lone file) must be wrapped in a <id>/
 * drawer by the caller - loose files must never pile up in the install dir
 * root (tester report: amipkg-client + Amelinium spilled their files there). */
/* Self-update must reach the binaries ACTUALLY IN USE, not just the data
 * prefix: on older layouts the running `amipkg` lives elsewhere (the early
 * Imager images shipped C:amipkg + SYS:Tools/amipkg-gui with the data drawer
 * behind an assign). Without this, `upgrade amipkg` kept installing the new
 * version into the prefix drawer while the user kept launching the old copy -
 * "it sees 0.5.2, installs it, and still runs the old one" (A4000 report).
 * After the recipe placed the new files, mirror each amipkg-family file onto
 * (a) the running program's own directory and (b) the legacy locations IF a
 * stale copy exists there. Best-effort: a failed copy never fails the update
 * (an in-use file just stays until the next run). */
static const char *selfupdate_basename(const char *path)
{
    const char *b = path, *p;
    for (p = path; *p; p++) if (*p == '/' || *p == ':') b = p + 1;
    return b;
}

/* Case-insensitive compare (Amiga filesystems); newlib's stricmp is unsafe. */
static int ci_eq(const char *a, const char *b)
{
    size_t k;
    for (k = 0; ; k++) {
        int ca = tolower((unsigned char)a[k]);
        int cb = tolower((unsigned char)b[k]);
        if (ca != cb) return 0;
        if (!ca) return 1;
    }
}

void amipkg_selfupdate_mirror(char (*paths)[256], size_t n)
{
    static const char *family[] = { "amipkg", "amipkg-gui", "amipkg-mui",
                                    "amipkg-gui.info", "amipkg-mui.info",
                                    "amipkg.guide", NULL };
    char own[300];
    BPTR l = GetProgramDir();
    size_t i, k, refreshed = 0;
    own[0] = '\0';
    if (l) NameFromLock(l, (STRPTR)own, sizeof own);
    for (i = 0; i < n; i++) {
        const char *base = selfupdate_basename(paths[i]);
        int in_family = 0;
        for (k = 0; family[k]; k++)
            if (ci_eq(base, family[k])) { in_family = 1; break; }
        if (!in_family) continue;
        /* (a) the running program's own drawer */
        if (own[0]) {
            char dst[340];
            size_t len = strlen(own);
            snprintf(dst, sizeof dst, "%s%s%s", own,
                     (len && own[len - 1] == ':') ? "" : "/", base);
            if (!ci_eq(dst, paths[i])) {
                BPTR dl = Lock((STRPTR)dst, ACCESS_READ);
                int existed = dl != 0;
                if (dl) UnLock(dl);
                /* Copy into the running drawer even when absent there:
                 * whoever launches from this drawer must get the new set. */
                if (copy_file(paths[i], dst)) refreshed++;
                (void)existed;
            }
        }
        /* (b) known legacy homes - refresh ONLY where a stale copy exists */
        {
            const char *legacy = NULL;
            char dst[64];
            if (ci_eq(base, "amipkg")) legacy = "C:amipkg";
            else if (ci_eq(base, "amipkg-gui")) legacy = "SYS:Tools/amipkg-gui";
            else if (ci_eq(base, "amipkg-mui")) legacy = "SYS:Tools/amipkg-mui";
            if (legacy) {
                snprintf(dst, sizeof dst, "%s", legacy);
                if (!ci_eq(dst, paths[i])) {
                    BPTR dl = Lock((STRPTR)dst, ACCESS_READ);
                    if (dl) {
                        UnLock(dl);
                        if (copy_file(paths[i], dst)) refreshed++;
                    }
                }
            }
        }
    }
    if (refreshed)
        printf("Refreshed %lu running/legacy cop%s of amipkg alongside the install.\n",
               (unsigned long)refreshed, refreshed == 1 ? "y" : "ies");
}

/* One shared walk buffer (BSS budget: 1 MB machines) - the callers below
 * never overlap, each does its own fresh walk. */
static char g_walk_pool[ARUN_MAX_OPS][256];
static int  g_walk_isdir[ARUN_MAX_OPS];

/* Does the extract dir contain at least one file? cmd_install checks this
 * BEFORE removing the previous version - never destroy an install on the
 * strength of an empty extraction. */
int amipkg_extract_nonempty(const char *extract_dir)
{
    char (*pool)[256] = g_walk_pool;
    int *is_dir = g_walk_isdir;
    size_t n, i;
    n = walk_tree(extract_dir, "", pool, is_dir, ARUN_MAX_OPS, 0);
    for (i = 0; i < n; i++) if (!is_dir[i]) return 1;
    return 0;
}

/* Empty cache/extract before an extraction.
 *
 * The drawer is SHARED between packages and was never cleared, so debris from
 * previous installs piled up. walk_tree() fills a FIXED-SIZE array
 * (ARUN_MAX_OPS): once the leftovers filled it, the files that were actually
 * just extracted fell off the end and the install silently did nothing,
 * reporting "no files matched". That bit a real machine three times, each time
 * cleared by hand, before being fixed here.
 *
 * Deletes files first, then directories deepest-first, because a drawer cannot
 * be removed until it is empty. Repeats while it is making progress: if the
 * leftover tree is itself larger than ARUN_MAX_OPS, one pass cannot see all of
 * it - which is the very condition this exists to clear.
 *
 * Returns the number of objects removed.
 */
int amipkg_extract_purge(const char *extract_dir)
{
    char (*pool)[256] = g_walk_pool;
    int *is_dir = g_walk_isdir;
    int total = 0, pass;
    BPTR l;

    l = Lock((STRPTR)extract_dir, ACCESS_READ);
    if (!l) return 0;                       /* nothing there yet */
    UnLock(l);

    for (pass = 0; pass < 8; pass++) {
        size_t n, i;
        int removed = 0;
        char path[512];

        n = walk_tree(extract_dir, "", pool, is_dir, ARUN_MAX_OPS, 0);
        if (n == 0) break;

        for (i = 0; i < n; i++) {           /* files */
            if (is_dir[i]) continue;
            snprintf(path, sizeof path, "%s/%s", extract_dir, pool[i]);
            /* A package may have left its files delete-protected. */
            SetProtection((STRPTR)path, 0);
            if (DeleteFile((STRPTR)path)) removed++;
        }
        for (i = n; i-- > 0; ) {            /* then drawers, deepest first */
            if (!is_dir[i]) continue;
            snprintf(path, sizeof path, "%s/%s", extract_dir, pool[i]);
            SetProtection((STRPTR)path, 0);
            if (DeleteFile((STRPTR)path)) removed++;
        }
        total += removed;
        if (removed == 0) break;            /* stuck - do not spin */
    }
    return total;
}

int amipkg_extract_single_top_dir(const char *extract_dir)
{
    char (*pool)[256] = g_walk_pool;
    int *is_dir = g_walk_isdir;
    size_t n, i;
    char first[256];
    int have = 0, seen_dir = 0;
    n = walk_tree(extract_dir, "", pool, is_dir, ARUN_MAX_OPS, 0);
    if (n == 0) return 0;
    first[0] = '\0';
    for (i = 0; i < n; i++) {
        const char *sl = strchr(pool[i], '/');
        size_t len = sl ? (size_t)(sl - pool[i]) : strlen(pool[i]);
        char comp[256];
        size_t k;
        if (len >= sizeof comp) len = sizeof comp - 1;
        memcpy(comp, pool[i], len); comp[len] = '\0';
        if (!have) { strcpy(first, comp); have = 1; }
        else {
            /* Amiga filesystems are case-insensitive - compare accordingly. */
            for (k = 0; ; k++) {
                int a = tolower((unsigned char)first[k]);
                int b = tolower((unsigned char)comp[k]);
                if (a != b) return 0;
                if (!a) break;
            }
        }
        if (sl) seen_dir = 1;                 /* something lives under the top */
        else if (is_dir[i]) seen_dir = 1;     /* the top entry itself is a dir */
    }
    return seen_dir;
}

/* Generic install for a recipe-less package (the fetch-only Aminet entries):
 * copy the whole extracted tree under `dest_root` (typically SYS:Programs), so
 * an archive that unpacked into e.g. "Fitz/" lands as SYS:Programs/Fitz/. This
 * is the "drop the Aminet app into a drawer" a user would do by hand - a
 * best-effort install (apps needing their own Installer may need manual setup).
 * Returns the count of installed files (recorded for clean removal). */
/* Uncapped, receipt-recording generic install. The old array-based path
 * silently TRUNCATED big archives: walk_tree stopped at 512 tree entries and
 * the caller recorded at most 256 receipt lines - AmiBlitz3 (1109 files)
 * arrived half-installed with "unresolved dependencies" (A4000 report).
 * This walks and copies recursively with no caps, appends every file to the
 * receipt as it goes, and afterwards PROMOTES bundled <top>/Libs/*.library
 * to LIBS: when missing there (the classic "copy our Libs drawer to your
 * system Libs" install instruction, e.g. AmiBlitz's wizard.library) -
 * promoted copies are receipt-recorded too, so remove cleans them up. */
typedef struct {
    FILE *rcpt;
    char (*out_paths)[256];
    size_t out_max, out_n, copied;
    char libs[40][300];        /* installed dest paths of bundled Libs/ */
    size_t nlibs;
    /* System-drawer routing (see amipkg_system_drawer_kind). When sysdest is
     * set, the program files go there FLAT and everything else goes to
     * companion/ with its structure intact. NULL = the ordinary whole-tree
     * copy, byte-for-byte the old behaviour. */
    const char *sysdest;
    const char *companion;
    int syskind;
    size_t n_sys, n_companion;
} gen_ctx;

/* An Amiga executable starts with HUNK_HEADER. Cheap and reliable - far
 * better than guessing from the name. */
static int is_hunk_executable(const char *path)
{
    FILE *f = fopen(path, "rb");
    unsigned char h[4];
    int ok = 0;
    if (!f) return 0;
    if (fread(h, 1, 4, f) == 4)
        ok = (h[0] == 0x00 && h[1] == 0x00 && h[2] == 0x03 && h[3] == 0xF3);
    fclose(f);
    return ok;
}

/* Does this file belong IN the system drawer, or beside it in the companion
 * drawer? Deliberately conservative: name conventions first, then the hunk
 * check for the drawers that hold plain executables. Anything unrecognised
 * goes to the companion, where it is harmless. */
static int belongs_in_system_drawer(int kind, const char *base, const char *src)
{
    if (has_suffix_ci(base, ".info")) return 0;      /* icons stay with the docs */
    switch (kind) {
    case SD_LIBS:    return has_suffix_ci(base, ".library");
    case SD_DEVS:    return has_suffix_ci(base, ".device");
    case SD_CLASSES: return has_suffix_ci(base, ".class") || has_suffix_ci(base, ".datatype");
    case SD_FONTS:   return has_suffix_ci(base, ".font");
    case SD_PREFS:   return has_suffix_ci(base, ".prefs") || is_hunk_executable(src);
    case SD_C:
    case SD_L:       return is_hunk_executable(src);
    case SD_S:       return !strchr(base, '.');      /* scripts have no suffix */
    default:         return 0;
    }
}

static void gen_install_rec(const char *src_root, const char *rel,
                            const char *dest_root, gen_ctx *cx)
{
    BPTR lock;
    struct FileInfoBlock *fib;
    char spath[512];
    if (rel[0]) snprintf(spath, sizeof spath, "%s/%s", src_root, rel);
    else        snprintf(spath, sizeof spath, "%s", src_root);
    lock = Lock((STRPTR)spath, ACCESS_READ);
    if (!lock) return;
    fib = (struct FileInfoBlock *)AllocDosObject(DOS_FIB, NULL);
    if (!fib) { UnLock(lock); return; }
    if (Examine(lock, fib) && fib->fib_DirEntryType > 0) {
        while (ExNext(lock, fib)) {
            char childrel[512];
            if (rel[0]) snprintf(childrel, sizeof childrel, "%s/%s", rel, fib->fib_FileName);
            else        snprintf(childrel, sizeof childrel, "%s", fib->fib_FileName);
            if (fib->fib_DirEntryType > 0) {
                gen_install_rec(src_root, childrel, dest_root, cx);
            } else {
                char src[600], dst[600], hex[65];
                snprintf(src, sizeof src, "%s/%s", src_root, childrel);
                if (cx->sysdest) {
                    /* System-drawer mode: programs go in FLAT (a command must
                     * sit at C: itself to be found), everything else lands in
                     * the companion drawer with its structure kept. */
                    const char *base = strrchr(childrel, '/');
                    base = base ? base + 1 : childrel;
                    if (belongs_in_system_drawer(cx->syskind, base, src)) {
                        const char *sep =
                            cx->sysdest[strlen(cx->sysdest) - 1] == ':' ? "" : "/";
                        snprintf(dst, sizeof dst, "%s%s%s", cx->sysdest, sep, base);
                        cx->n_sys++;
                    } else {
                        snprintf(dst, sizeof dst, "%s/%s", cx->companion, childrel);
                        cx->n_companion++;
                    }
                } else {
                    snprintf(dst, sizeof dst, "%s/%s", dest_root, childrel);
                }
                if (copy_file(src, dst)) {
                    cx->copied++;
                    if (cx->rcpt) {
                        if (sha256_of_file(dst, hex) == 0) fprintf(cx->rcpt, "%s|%s\n", dst, hex);
                        else                                fprintf(cx->rcpt, "%s\n", dst);
                    }
                    if (cx->out_n < cx->out_max) {
                        strncpy(cx->out_paths[cx->out_n], dst, 255);
                        cx->out_paths[cx->out_n][255] = 0;
                        cx->out_n++;
                    }
                    /* <top>/Libs/<name>.library (or Libs/ at the wrap root) */
                    {
                        const char *l = strstr(childrel, "Libs/");
                        size_t cl = strlen(childrel);
                        if (l && (l == childrel || *(l - 1) == '/')
                            && strchr(l + 5, '/') == NULL
                            && cl > 8 && ci_eq(childrel + cl - 8, ".library")
                            && cx->nlibs < sizeof cx->libs / sizeof cx->libs[0]) {
                            strncpy(cx->libs[cx->nlibs], dst, sizeof cx->libs[0] - 1);
                            cx->libs[cx->nlibs][sizeof cx->libs[0] - 1] = 0;
                            cx->nlibs++;
                        }
                    }
                }
            }
        }
    }
    FreeDosObject(DOS_FIB, fib);
    UnLock(lock);
}

/* Install into a SYSTEM drawer: programs flat into `sysdest`, the rest into
 * `companion`. Returns files copied; *n_sys / *n_comp report the split so the
 * caller can tell the user where things went. */
size_t amipkg_install_generic_routed(const char *extract_dir, const char *sysdest,
                                     const char *companion, const char *id,
                                     char (*out_paths)[256], size_t max,
                                     size_t *n_sys, size_t *n_comp)
{
    static gen_ctx cx;
    char rp[192];
    memset(&cx, 0, sizeof cx);
    cx.out_paths = out_paths; cx.out_max = max;
    cx.sysdest = sysdest; cx.companion = companion;
    cx.syskind = amipkg_system_drawer_kind(sysdest);
    snprintf(rp, sizeof rp, "%sdb/files/%s.files", amipkg_prefix(), id);
    cx.rcpt = fopen(rp, "a");
    gen_install_rec(extract_dir, "", sysdest, &cx);
    if (cx.rcpt) fclose(cx.rcpt);
    if (n_sys)  *n_sys  = cx.n_sys;
    if (n_comp) *n_comp = cx.n_companion;
    return cx.copied;
}

size_t amipkg_install_generic_recorded(const char *extract_dir, const char *dest_root,
                                       const char *id, char (*out_paths)[256], size_t max)
{
    static gen_ctx cx;
    char rp[192];
    size_t i, promoted = 0;
    memset(&cx, 0, sizeof cx);
    cx.out_paths = out_paths; cx.out_max = max;
    snprintf(rp, sizeof rp, "%sdb/files/%s.files", amipkg_prefix(), id);
    cx.rcpt = fopen(rp, "a");
    gen_install_rec(extract_dir, "", dest_root, &cx);
    for (i = 0; i < cx.nlibs; i++) {
        const char *base = selfupdate_basename(cx.libs[i]);
        char libdst[300], hex[65];
        BPTR l;
        snprintf(libdst, sizeof libdst, "LIBS:%s", base);
        l = Lock((STRPTR)libdst, ACCESS_READ);
        if (l) { UnLock(l); continue; }   /* never overwrite a system lib */
        if (copy_file(cx.libs[i], libdst)) {
            promoted++;
            if (cx.rcpt) {
                if (sha256_of_file(libdst, hex) == 0) fprintf(cx.rcpt, "%s|%s\n", libdst, hex);
                else                                   fprintf(cx.rcpt, "%s\n", libdst);
            }
        }
    }
    if (cx.rcpt) fclose(cx.rcpt);
    if (promoted)
        printf("Promoted %lu bundled librar%s to LIBS: (missing there).\n",
               (unsigned long)promoted, promoted == 1 ? "y" : "ies");
    return cx.copied;
}

size_t amipkg_install_generic(const char *extract_dir, const char *dest_root,
                              char (*out_paths)[256], size_t max)
{
    char (*pool)[256] = g_walk_pool;
    int *is_dir = g_walk_isdir;
    size_t n, i, out = 0;
    n = walk_tree(extract_dir, "", pool, is_dir, ARUN_MAX_OPS, 0);
    for (i = 0; i < n; i++) {
        char src[300], dst[300];
        if (is_dir[i]) continue;
        snprintf(src, sizeof src, "%s/%s", extract_dir, pool[i]);
        snprintf(dst, sizeof dst, "%s/%s", dest_root, pool[i]);
        if (copy_file(src, dst) && out < max) {
            strncpy(out_paths[out], dst, 255); out_paths[out][255] = '\0';
            out++;
        }
    }
    return out;
}

#endif /* __amigaos__ */
