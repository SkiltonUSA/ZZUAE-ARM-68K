/* arun.c - amipkg portable core. Recipe execution PLAN (mirror of RecipeRunner). */

#include "arun.h"
#include <ctype.h>
#include <stdio.h>
#include <string.h>
#ifdef __amigaos__
#include <exec/execbase.h>
#include <proto/exec.h>
#endif

/* CPU class from exec AttnFlags, mirroring AminetBuildtimeInstaller.is68040plus/
 * is68020plus: 2 = 68040/68060, 1 = 68020/68030, 0 = 68000/68010. On a non-Amiga
 * host build of the core (unit tests / the pkgindex converter never runs this),
 * assume a modern 68040+ target so plans still lower deterministically. */
static int cpu_class(void)
{
#ifdef __amigaos__
    UWORD f = SysBase->AttnFlags;
    if (f & (AFF_68040 | AFF_68060)) return 2;
    if (f & (AFF_68020 | AFF_68030)) return 1;
    return 0;
#else
    return 2;
#endif
}

/* fnmatch with FNM_CASEFOLD and '*' spanning '/' - the exact matching
 * AminetInterimStager uses (POSIX fnmatch(..., FNM_CASEFOLD), no FNM_PATHNAME).
 * Iterative backtracking; '?' matches one char, '*' matches any run. */
int arun_glob_match(const char *pat, const char *str)
{
    const char *star = 0, *ss = 0;
    while (*str) {
        int pc = (unsigned char)*pat, sc = (unsigned char)*str;
        if (pc == '*') { star = pat++; ss = str; continue; }
        if (pc == '?' ||
            tolower(pc) == tolower(sc)) { pat++; str++; continue; }
        if (star) { pat = star + 1; str = ++ss; continue; }
        return 0;
    }
    while (*pat == '*') pat++;
    return *pat == '\0';
}

/* Join a<sep>b into out, truncating deliberately rather than overflowing.
 *
 * snprintf would do the same, but GCC's -Wformat-truncation cannot see that
 * the truncation is intended and fails the -Werror build. Doing it explicitly
 * says so in the code. Enlarging arun_op instead is not free: it is 512 ops of
 * fixed-size fields on machines with 1 MB. */
static void join_path(char *out, size_t n, const char *a,
                      const char *sep, const char *b)
{
    size_t la, ls, lb;
    if (!n) return;
    la = strlen(a); if (la >= n - 1) la = n - 1;
    memcpy(out, a, la);
    ls = strlen(sep); if (la + ls >= n - 1) ls = n - 1 - la;
    memcpy(out + la, sep, ls);
    lb = strlen(b); if (la + ls + lb >= n - 1) lb = n - 1 - la - ls;
    memcpy(out + la + ls, b, lb);
    out[la + ls + lb] = '\0';
}

static void copy_str(char *dst, size_t dstsize, const char *src)
{
    size_t n = src ? strlen(src) : 0;
    if (n >= dstsize) n = dstsize - 1;
    if (n) memcpy(dst, src, n);
    dst[n] = '\0';
}

/* '\' -> '/' normalization (recipes may still carry raw CSV separators). */
static void normalize(char *s)
{
    for (; *s; s++) if (*s == '\\') *s = '/';
}

/* Component count of a path ('/'-separated). */
static size_t depth_of(const char *s)
{
    size_t d = 1;
    for (; *s; s++) if (*s == '/') d++;
    return d;
}

/* Last path component. */
static const char *basename_of(const char *s)
{
    const char *slash = strrchr(s, '/');
    return slash ? slash + 1 : s;
}

static int push(arun_plan *p, arun_kind kind)
{
    arun_op *o;
    if (p->count >= ARUN_MAX_OPS) { p->overflow = 1; return 0; }
    o = &p->ops[p->count++];
    memset(o, 0, sizeof *o);
    o->kind = kind;
    return 1;
}

static const char JUNK_PREFIX[] = "__uae___";

static int is_junk(const char *base)
{
    if (strcmp(base, ".DS_Store") == 0) return 1;
    if (strncmp(base, JUNK_PREFIX, sizeof JUNK_PREFIX - 1) == 0) return 1;
    /* bundled Installer files (case-insensitive), files only */
    if (arun_glob_match("Install", base) || arun_glob_match("Install.info", base)
        || arun_glob_match("Install *", base) || arun_glob_match("Install *.info", base)
        || arun_glob_match("*.installer", base) || arun_glob_match("*.installer.info", base))
        return 1;
    return 0;
}

/* copyTree junk filter - a FAITHFUL mirror of EngineFS.copyTreeFiltered's
 * removeMatching (the simple-app / whole-drawer path). Unlike is_junk (the
 * copyGlob interim stager, which strips bundled vendor Installer files), the
 * tree copy KEEPS the Install / "*.installer" files - it lays the app drawer down verbatim,
 * dropping only host/UAE filesystem cruft. Mixing the two filters silently
 * deletes an app's bundled Installer, diverging from the shipped image. */
static int is_tree_junk(const char *base)
{
    if (strcmp(base, ".DS_Store") == 0) return 1;
    if (strcmp(base, ".keep") == 0) return 1;
    if (strcmp(base, ".keepfile") == 0) return 1;
    if (strcmp(base, "_UAEFSDB.___") == 0) return 1;
    if (strcmp(base, "__MACOSX") == 0) return 1;          /* dir; inert for .lha */
    if (arun_glob_match("._*", base)) return 1;           /* AppleDouble (._*) */
    if (arun_glob_match("*.info.txt", base)) return 1;    /* suffixesLower */
    return 0;
}

/* copyGlob for one op: match entries against the (normalized) glob at its
 * depth, appending COPY ops dest = "<dest>/<basename>". Mirrors stageWildcard
 * (files) and stageExact (a literal path with an optional rename). */
static void plan_copy(const arecipe_op *op, arun_plan *plan,
                      const char *const *entries, const int *is_dir, size_t n)
{
    char glob[256], dest[256], rename[64];
    size_t i, gdepth;
    int has_star;
    copy_str(glob, sizeof glob, op->src); normalize(glob);
    copy_str(dest, sizeof dest, op->dest); normalize(dest);
    copy_str(rename, sizeof rename, op->rename); normalize(rename);
    has_star = strchr(glob, '*') != 0;
    gdepth = depth_of(glob);

    for (i = 0; i < n; i++) {
        const char *e = entries[i];
        const char *base = basename_of(e);
        if (has_star) {
            if (depth_of(e) != gdepth) continue;
            if (!arun_glob_match(glob, e)) continue;
            if (is_dir && is_dir[i]) continue;            /* files only (dirs implied) */
            if (is_junk(base)) continue;
        } else {
            if (strcmp(e, glob) != 0) continue;           /* exact path */
        }
        if (push(plan, ARUN_COPY)) {
            arun_op *o = &plan->ops[plan->count - 1];
            copy_str(o->src, sizeof o->src, e);
            {
                const char *leaf = (!has_star && rename[0]) ? basename_of(rename) : base;
                if (dest[0] && dest[strlen(dest) - 1] == ':')
                    /* assign-absolute dest ("AMIPKG:"): join without '/' -
                     * "X:/y" would mean the PARENT of X: in AmigaDOS. */
                    join_path(o->dest, sizeof o->dest, dest, "", leaf);
                else if (dest[0])
                    join_path(o->dest, sizeof o->dest, dest, "/", leaf);
                else
                    copy_str(o->dest, sizeof o->dest, leaf);
            }
        }
    }
}

/* casefold: does path `e` live under directory `prefix` (length plen)? i.e.
 * e starts with prefix and the next char is a component slash. */
static int ci_prefix_dir(const char *e, const char *prefix, size_t plen)
{
    size_t i;
    for (i = 0; i < plen; i++)
        if (tolower((unsigned char)e[i]) != tolower((unsigned char)prefix[i])) return 0;
    return e[plen] == '/';
}

/* copyTree: recursive, structure-preserving copy of the archive subtree under
 * `op->src` (the <appName> drawer if any entry lives under it, else the extract
 * root) to `op->dest`, junk stripped. Emits one ARUN_COPY per file, with
 * dest = "<dest>/<path-relative-to-app_root>". Faithful mirror of
 * FS.copyTreeFiltered (the simple-app installer body). */
static void plan_tree(const arecipe_op *op, arun_plan *plan,
                      const char *const *entries, const int *is_dir, size_t n)
{
    char prefix[256], dest[256];
    size_t i, plen;
    int have_appdir = 0;
    copy_str(prefix, sizeof prefix, op->src); normalize(prefix);
    copy_str(dest, sizeof dest, op->dest); normalize(dest);
    plen = strlen(prefix);
    if (plen) for (i = 0; i < n; i++)
        if (ci_prefix_dir(entries[i], prefix, plen)) { have_appdir = 1; break; }
    for (i = 0; i < n; i++) {
        const char *e = entries[i], *rel;
        if (is_dir && is_dir[i]) continue;               /* files only (dirs implied) */
        if (have_appdir) {
            if (!ci_prefix_dir(e, prefix, plen)) continue;
            rel = e + plen + 1;                          /* strip "<appName>/" */
        } else {
            rel = e;                                     /* app_root = extract root */
        }
        if (is_tree_junk(basename_of(e))) continue;
        if (push(plan, ARUN_COPY)) {
            arun_op *o = &plan->ops[plan->count - 1];
            copy_str(o->src, sizeof o->src, e);
            if (dest[0]) join_path(o->dest, sizeof o->dest, dest, "/", rel);
            else copy_str(o->dest, sizeof o->dest, rel);
        }
    }
}

/* AROP_CPU_PLACE_FILE: pick the CPU-class library build (src = 68040+, overlay =
 * 68020/030), skip on 68000, and lower to a single ARUN_COPY renamed into dest.
 * Faithful mirror of ClassicPackages.installMpega's is68040plus/is68020plus pick;
 * dest/rename joining follows plan_copy exactly (incl. the assign-absolute rule). */
static void plan_cpu(const arecipe_op *op, arun_plan *plan,
                     const char *const *entries, const int *is_dir, size_t n)
{
    char pick[128], dest[128], rename[64];
    size_t i;
    int cls = cpu_class();
    (void)is_dir;
    if (cls >= 2)      copy_str(pick, sizeof pick, op->src);      /* 68040/060 */
    else if (cls >= 1) copy_str(pick, sizeof pick, op->overlay);  /* 68020/030 */
    else               return;                                   /* 68000: skip */
    normalize(pick);
    if (!pick[0]) return;
    copy_str(dest, sizeof dest, op->dest); normalize(dest);
    copy_str(rename, sizeof rename, op->rename); normalize(rename);
    for (i = 0; i < n; i++) {
        if (strcmp(entries[i], pick) != 0) continue;   /* exact path in the extract */
        if (push(plan, ARUN_COPY)) {
            arun_op *o = &plan->ops[plan->count - 1];
            const char *leaf = rename[0] ? basename_of(rename) : basename_of(pick);
            copy_str(o->src, sizeof o->src, pick);
            if (dest[0] && dest[strlen(dest) - 1] == ':')
                join_path(o->dest, sizeof o->dest, dest, "", leaf);
            else if (dest[0])
                join_path(o->dest, sizeof o->dest, dest, "/", leaf);
            else
                copy_str(o->dest, sizeof o->dest, leaf);
        }
        return;
    }
}

int arun_plan_build(const arecipe *recipe,
                    const char *const *entries, const int *is_dir, size_t n_entries,
                    arun_plan *out)
{
    size_t i;
    memset(out, 0, sizeof *out);
    if (recipe->has_unknown) return 1;   /* refuse a recipe we can't fully run */
    /* Schema 2 = assign-absolute placeFile dests ("AMIPKG:x"). Refuse
     * anything newer than we understand - a silent mis-run is worse. */
    if (recipe->schema > 2) return 1;

    for (i = 0; i < recipe->op_count; i++) {
        const arecipe_op *op = &recipe->ops[i];
        switch (op->type) {
        case AROP_COPY_GLOB:
        case AROP_PLACE_FILE:
            plan_copy(op, out, entries, is_dir, n_entries);
            break;
        case AROP_COPY_TREE:
            plan_tree(op, out, entries, is_dir, n_entries);
            break;
        case AROP_CPU_PLACE_FILE:
            plan_cpu(op, out, entries, is_dir, n_entries);
            break;
        case AROP_DRAWER_ICON:
            /* One op, no tree matching: the AmigaOS layer reads
             * ENVARC:Sys/def_drawer.info (else the archive fallback op->src),
             * forces do_Type=drawer + NO_ICON_POSITION, and writes op->dest. */
            if (push(out, ARUN_DRAWER_ICON)) {
                arun_op *o = &out->ops[out->count - 1];
                copy_str(o->src, sizeof o->src, op->src);
                copy_str(o->dest, sizeof o->dest, op->dest);
            }
            break;
        case AROP_STRIP_JUNK:
            /* handled implicitly during copy (junk is never copied) - no op */
            break;
        case AROP_MERGE_NESTED:
            /* Foo/Foo folding is a dest-tree concern the AmigaOS layer applies
             * after copy; represented as no planned op here. */
            break;
        case AROP_SET_EXEC:
            if (push(out, ARUN_SET_EXEC))
                copy_str(out->ops[out->count - 1].dest, sizeof out->ops[0].dest, op->scope);
            break;
        case AROP_SCRIPT_INJECT:
            if (push(out, ARUN_SCRIPT)) {
                arun_op *o = &out->ops[out->count - 1];
                copy_str(o->dest, sizeof o->dest, op->target);
                copy_str(o->overlay, sizeof o->overlay, op->overlay);
                copy_str(o->marker, sizeof o->marker, op->marker);
            }
            break;
        case AROP_TOOLTYPE_EDIT:
        case AROP_MAKE_ASSIGN:
            /* deferred (parity with the host RecipeRunner's deferredOps) */
            break;
        case AROP_PRE_SCRIPT:
        case AROP_POST_SCRIPT:
        case AROP_REMOVE_SCRIPT:
            /* not copy-plan ops: the AmigaOS layer Executes them around the
             * plan (amipkg_run_recipe); nothing to place here */
            break;
        default:
            return 1;
        }
    }
    return 0;
}
