#!/usr/bin/env python3
"""golden.py - faithfulness harness for amipkg on-device installer ports.

The contract (PackageRecipeConverter): an on-device `amipkg install` must produce
BYTE-IDENTICAL results to Amiga Imager's build-time install. This tool proves it.

The golden reference is a host-built image's *already-installed* tree - e.g. the
running iPad image, which Amiga Imager built with Solas et al. already in place.

  capture <host> <pkgid> <amiga-path>...   snapshot host-installed tree -> golden/<pkgid>.json
  verify  <host> <pkgid> <root> <amiga-path>...
                                           snapshot a candidate tree (e.g. a
                                           scratch DIR= amipkg installed into) and
                                           diff it against the golden.

A snapshot records, per file, {sha256, size, protection} keyed by path RELATIVE
to a common root, so a golden at SYS:Programs/Solas compares against a candidate
at RAM:t/Programs/Solas. Directories are recorded too (presence + protection).
"""
import sys, os, json, hashlib

sys.path.insert(0, os.path.expanduser("~/Development/amimcp/server"))
from amiga import Amiga  # noqa: E402

GOLDEN_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "golden")


def _normalize(name, data):
    """Zero runtime-mutable icon position so the faithfulness diff reflects the
    BUILD output, not Workbench's later snapshot. A DiskObject (.info, magic
    0xE310) carries do_CurrentX/Y at 0x3A/0x3E; the build emits NO_POSITION
    (0x80000000), but Workbench overwrites both with a real position the first
    time it auto-places the icon. That field is runtime-owned, not install
    output, so exclude it from the hash."""
    if name.lower().endswith(".info") and len(data) >= 0x42 and data[0:2] == b"\xe3\x10":
        data = bytearray(data)
        data[0x3A:0x42] = b"\x00" * 8   # do_CurrentX + do_CurrentY
        return bytes(data)
    return data


def _hash(name, data):
    return hashlib.sha256(_normalize(name, data)).hexdigest()


def _walk(a, path, root, out):
    """Recurse an AmigaDOS path; record files (hash/size/prot) + dirs, keyed
    by the path relative to `root` (case-folded, '/'-joined)."""
    for e in a.list_dir(path):
        full = path.rstrip("/") + "/" + e.name if not path.endswith(":") else path + e.name
        rel = full[len(root):].lstrip("/") if full.lower().startswith(root.lower()) else full
        rel = rel.lower()
        if e.is_dir:
            out[rel] = {"kind": "dir", "prot": e.protection}
            _walk(a, full, root, out)
        else:
            data = a.read_file(full)
            out[rel] = {"kind": "file", "size": len(data),
                        "sha256": _hash(e.name, data), "prot": e.protection}


def snapshot(a, paths, root):
    out = {}
    for p in paths:
        # a leaf file, or a directory to recurse
        try:
            entries = a.list_dir(p)
            _walk(a, p, root, out)
        except Exception:
            # treat as a single file (e.g. the drawer .info next to the dir)
            data = a.read_file(p)
            rel = p[len(root):].lstrip("/").lower() if p.lower().startswith(root.lower()) else p.lower()
            leaf = p.replace(":", "/").rsplit("/", 1)[-1]
            out[rel] = {"kind": "file", "size": len(data),
                        "sha256": _hash(leaf, data), "prot": "----rwed"}
    return out


def common_root(paths):
    """The install root shared by the given paths, e.g. 'SYS:Programs' for
    ['SYS:Programs/Solas', 'SYS:Programs/Solas.info']."""
    p0 = paths[0]
    return p0[: p0.rfind("/")] if "/" in p0 else p0


def cmd_capture(host, pkgid, paths):
    a = Amiga(host, token="a4000", timeout=60)
    snap = snapshot(a, paths, common_root(paths))
    os.makedirs(GOLDEN_DIR, exist_ok=True)
    dst = os.path.join(GOLDEN_DIR, pkgid + ".json")
    json.dump({"pkgid": pkgid, "root": common_root(paths), "paths": paths, "tree": snap},
              open(dst, "w"), indent=1, sort_keys=True)
    print(f"captured golden: {pkgid}  ({sum(1 for v in snap.values() if v['kind']=='file')} files, "
          f"{sum(1 for v in snap.values() if v['kind']=='dir')} dirs) -> {dst}")


def cmd_verify(host, pkgid, root, paths):
    gp = os.path.join(GOLDEN_DIR, pkgid + ".json")
    golden = json.load(open(gp))["tree"]
    a = Amiga(host, token="a4000", timeout=60)
    cand = snapshot(a, paths, root)
    gk, ck = set(golden), set(cand)
    missing, extra, changed = sorted(gk - ck), sorted(ck - gk), []
    for k in sorted(gk & ck):
        g, c = golden[k], cand[k]
        diffs = [f for f in ("kind", "size", "sha256", "prot")
                 if g.get(f) != c.get(f) and f in g]
        if diffs:
            changed.append((k, diffs, g, c))
    ok = not (missing or extra or changed)
    print(f"GOLDEN {pkgid}: {'PASS ✅ byte-identical' if ok else 'FAIL ❌'}")
    for k in missing: print(f"  MISSING  {k}")
    for k in extra:   print(f"  EXTRA    {k}")
    for k, d, g, c in changed:
        print(f"  CHANGED  {k}  [{','.join(d)}]  golden={ {f:g.get(f) for f in d} }  cand={ {f:c.get(f) for f in d} }")
    return 0 if ok else 1


def main():
    if len(sys.argv) < 4:
        print(__doc__); return 2
    cmd, host, pkgid = sys.argv[1], sys.argv[2], sys.argv[3]
    if cmd == "capture":
        cmd_capture(host, pkgid, sys.argv[4:]); return 0
    if cmd == "verify":
        return cmd_verify(host, pkgid, sys.argv[4], sys.argv[5:])
    print(__doc__); return 2


if __name__ == "__main__":
    sys.exit(main())
