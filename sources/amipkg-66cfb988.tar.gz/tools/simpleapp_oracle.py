#!/usr/bin/env python3
"""simpleapp_oracle.py - archive-based faithfulness check for the simple-app
recipe (copyTree + drawerIcon), independent of any live host-build snapshot.

Unlike golden.py (which captures a live, Workbench-mutable image), this builds
the EXPECTED tree straight from the pinned .lha:

  copyTree  <appName>/*  ->  <destPath>/<rel>   (is_tree_junk stripped, mirroring
                                                 EngineFS.copyTreeFiltered)
  drawerIcon                ->  <destPath>.info  (ENVARC:Sys/def_drawer.info with
                                                 do_Type=WBDRAWER, pos=NO_POSITION)

then diffs an actual on-device `amipkg install` against it. No live golden, so it
is immune to Workbench icon mutation AND to the shipped-image-vs-catalog version
skew (it verifies whatever version the catalog pins).

  verify <host> <archive.lha> <appName> <destPath>
     e.g. verify 192.168.178.33 .../LumiReg_1.1.lha LumiReg Programs/LumiReg
"""
import sys, os, subprocess, hashlib, tempfile, shutil

sys.path.insert(0, os.path.expanduser("~/Development/amimcp/server"))
from amiga import Amiga  # noqa: E402


def is_tree_junk(base):
    """Mirror of arun.c is_tree_junk / EngineFS.copyTreeFiltered removeMatching."""
    if base in (".DS_Store", ".keep", ".keepfile", "_UAEFSDB.___", "__MACOSX"):
        return True
    if base.startswith("._"):
        return True
    if base.lower().endswith(".info.txt"):
        return True
    return False


def norm(name, data):
    """golden.py's normalize: zero runtime-mutable icon position (0x3A..0x42)."""
    if name.lower().endswith(".info") and len(data) >= 0x42 and data[0:2] == b"\xe3\x10":
        d = bytearray(data)
        d[0x3A:0x42] = b"\x00" * 8
        return bytes(d)
    return data


def h(name, data):
    return hashlib.sha256(norm(name, data)).hexdigest()


def extract(archive):
    tmp = tempfile.mkdtemp(prefix="oracle-")
    subprocess.run(["unar", "-q", "-f", "-o", tmp, archive], check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # unar wraps in a top dir named after the archive; descend if single wrapper
    kids = [os.path.join(tmp, x) for x in os.listdir(tmp)]
    if len(kids) == 1 and os.path.isdir(kids[0]):
        return tmp, kids[0]
    return tmp, tmp


def app_root(root, app):
    """plan_tree: app_root = <appName> subdir if present (case-insensitive), else root."""
    for x in os.listdir(root):
        if x.lower() == app.lower() and os.path.isdir(os.path.join(root, x)):
            return os.path.join(root, x)
    return root


def expected_tree(extract_root, app, dest, def_drawer):
    """Build {amiga-relative-path(lower): (name, sha)} the recipe should produce."""
    ar = app_root(extract_root, app)
    exp = {}
    for dirpath, dirnames, filenames in os.walk(ar):
        # prune __MACOSX subtrees (host dirNames:[__MACOSX])
        dirnames[:] = [d for d in dirnames if d != "__MACOSX"]
        for fn in filenames:
            if is_tree_junk(fn):
                continue
            full = os.path.join(dirpath, fn)
            rel = os.path.relpath(full, ar).replace(os.sep, "/")
            key = (dest + "/" + rel).lower()
            exp[key] = (fn, h(fn, open(full, "rb").read()))
    # drawerIcon: def_drawer.info with do_Type=WBDRAWER; position normalized away
    di = bytearray(def_drawer)
    di[0x30] = 0x02
    icon = dest + ".info"
    exp[icon.lower()] = (icon, h(".info", bytes(di)))
    return exp


def actual_tree(a, dest):
    """Snapshot the on-device install: <dest>/** + <dest>.info, keyed like exp."""
    out = {}

    def walk(path):
        for e in a.list_dir(path):
            full = path.rstrip("/") + "/" + e.name
            if e.is_dir:
                walk(full)
            else:
                data = a.read_file(full)
                # key relative to SYS: -> "programs/lumireg/..."
                rel = full.split(":", 1)[1].lower()
                out[rel] = (e.name, h(e.name, data))
    walk("SYS:" + dest)
    iconp = "SYS:" + dest + ".info"
    out[(dest + ".info").lower()] = ("x.info", h(".info", a.read_file(iconp)))
    return out


def main():
    if len(sys.argv) != 6 or sys.argv[1] != "verify":
        print(__doc__); return 2
    _, _, host, archive, app, dest = sys.argv
    a = Amiga(host, token="a4000", timeout=60)
    def_drawer = a.read_file("ENVARC:Sys/def_drawer.info")
    tmp, root = extract(archive)
    try:
        exp = expected_tree(root, app, dest, def_drawer)
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    act = actual_tree(a, dest)
    ek, ak = set(exp), set(act)
    missing, extra = sorted(ek - ak), sorted(ak - ek)
    changed = [k for k in (ek & ak) if exp[k][1] != act[k][1]]
    ok = not (missing or extra or changed)
    print(f"ORACLE {app} ({os.path.basename(archive)}): "
          f"{'PASS ✅ byte-identical to archive+recipe' if ok else 'FAIL ❌'}  "
          f"({len(exp)} expected files)")
    for k in missing: print(f"  MISSING  {k}   (recipe should produce, install lacks)")
    for k in extra:   print(f"  EXTRA    {k}   (install has, recipe would not)")
    for k in changed: print(f"  CHANGED  {k}   exp={exp[k][1][:12]} act={act[k][1][:12]}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
