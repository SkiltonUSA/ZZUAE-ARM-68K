#!/usr/bin/env python3
"""recipe_oracle.py - archive-based faithfulness check for ANY portable recipe
(copyTree / copyGlob / placeFile / drawerIcon), the general form of
simpleapp_oracle.py.

Reads a package's recipe from the signed catalog, extracts the pinned archive,
interprets each op the way amipkg's arun.c plan_* functions do to build the
EXPECTED on-device tree, then diffs an actual `amipkg install` against it. No
live golden -> immune to Workbench mutation and catalog-vs-image version skew.

  verify <host> <catalog.json> <pkgid> <archive.lha>

copyTree dests are treated as authoritative (extras flagged); placeFile/copyGlob
single-file dests are not walked for extras (they land among unrelated system
files like Libs:/Prefs:).
"""
import sys, os, subprocess, hashlib, tempfile, shutil, json, fnmatch, unicodedata


def _k(s):
    """Canonical compare key: NFC (Amiga Latin-1 vs macOS NFD extract) + lower."""
    return unicodedata.normalize("NFC", s).lower()

sys.path.insert(0, os.path.expanduser("~/Development/amimcp/server"))
from amiga import Amiga  # noqa: E402


def is_tree_junk(base):   # mirror arun.c is_tree_junk (copyTree path)
    if base in (".DS_Store", ".keep", ".keepfile", "_UAEFSDB.___", "__MACOSX"):
        return True
    return base.startswith("._") or base.lower().endswith(".info.txt")


def is_junk(base):        # mirror arun.c is_junk (copyGlob path)
    if base == ".DS_Store" or base.startswith("__uae___"):
        return True
    low = base.lower()
    return low in ("install", "install.info") or low.startswith("install ") \
        or low.endswith(".installer") or low.endswith(".installer.info")


def norm(name, data):
    if name.lower().endswith(".info") and len(data) >= 0x42 and data[0:2] == b"\xe3\x10":
        d = bytearray(data); d[0x3A:0x42] = b"\x00" * 8; return bytes(d)
    return data


def h(name, data):
    return hashlib.sha256(norm(name, data)).hexdigest()


def depth(p):
    return p.strip("/").count("/")


def extract(archive):
    tmp = tempfile.mkdtemp(prefix="oracle-")
    # -D (--no-directory): never add an enclosing folder, so the layout is the
    # archive's NATIVE top-level structure — exactly what amipkg's on-Amiga lha
    # extractor sees (recipe src paths are archive-relative WITH the real top
    # dir, e.g. "mpega_library/libs/..."). Descending a single wrapper would
    # strip a real top dir and desync from amipkg.
    subprocess.run(["unar", "-q", "-D", "-f", "-o", tmp, archive], check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    # Amiga protection bits can extract without owner-read; make readable to hash.
    subprocess.run(["chmod", "-R", "u+rwX", tmp], check=False,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return tmp, tmp


def list_files(root):
    """[(rel-path, abs-path)] for every file under root, '/'-joined, __MACOSX pruned."""
    out = []
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d != "__MACOSX"]
        for fn in fns:
            full = os.path.join(dp, fn)
            rel = os.path.relpath(full, root).replace(os.sep, "/")
            out.append((rel, full))
    return out


def app_root(root, app):
    # Resolve app (possibly a nested path like "AmiSSL/Certs") under root,
    # case-insensitively, mirroring plan_tree's ci_prefix_dir. Falls back to the
    # extract root when the prefix has no matching dir (plan_tree's else branch).
    cur = root
    for comp in app.split("/"):
        nxt = None
        try:
            for x in os.listdir(cur):
                if x.lower() == comp.lower() and os.path.isdir(os.path.join(cur, x)):
                    nxt = os.path.join(cur, x); break
        except OSError:
            pass
        if nxt is None:
            return root
        cur = nxt
    return cur


def op_copy_tree(op, root, files, exp, tree_dests):
    ar = app_root(root, op["src"])
    tree_dests.append(op["dest"].lower())
    for rel, full in list_files(ar):
        if is_tree_junk(os.path.basename(rel)):
            continue
        key = _k(op["dest"] + "/" + rel)
        exp[key] = (os.path.basename(rel), h(os.path.basename(rel), open(full, "rb").read()))


def op_copy_glob(op, root, files, exp):
    glob = op["src"]; rename = op.get("rename"); dest = op["dest"]
    has_star = "*" in glob
    for rel, full in files:
        if has_star:
            if depth(rel) != depth(glob) or not fnmatch.fnmatch(rel.lower(), glob.lower()):
                continue
            if is_junk(os.path.basename(rel)):
                continue
            leaf = os.path.basename(rel)
        else:
            if rel.lower() != glob.lower():
                continue
            leaf = os.path.basename(rename) if rename else os.path.basename(rel)
        key = _k(dest + "/" + leaf)
        exp[key] = (leaf, h(leaf, open(full, "rb").read()))


def op_place_file(op, root, files, exp):
    glob = op["src"]; dest = op["dest"]
    for rel, full in files:
        if rel.lower() != glob.lower():
            continue
        leaf = os.path.basename(rel)
        key = _k(dest + "/" + leaf)
        exp[key] = (leaf, h(leaf, open(full, "rb").read()))


def op_cpu_place_file(op, root, files, exp, cpu_class):
    # amipkg picks by AttnFlags: 68040+ -> cpu040, 68020/030 -> cpu020, else skip.
    src = op["cpu040"] if cpu_class >= 2 else (op["cpu020"] if cpu_class >= 1 else None)
    if not src:
        return
    dest = op["dest"]; rename = op.get("rename")
    for rel, full in files:
        if rel.lower() != src.lower():
            continue
        leaf = os.path.basename(rename) if rename else os.path.basename(rel)
        key = _k(dest + "/" + leaf) if not dest.endswith(":") else _k(dest + leaf)
        exp[key] = (leaf, h(leaf, open(full, "rb").read()))
        return


def op_drawer_icon(op, root, files, exp, def_drawer):
    di = bytearray(def_drawer); di[0x30] = 0x02
    dest = op["dest"]
    exp[_k(dest)] = (dest, h(".info", bytes(di)))


def actual_for(a, exp_keys, tree_dests):
    out = {}
    seen = set()
    # walk copyTree dests fully (authoritative -> catch extras)
    for td in tree_dests:
        def walk(path, base):
            for e in a.list_dir(path):
                full = path.rstrip("/") + "/" + e.name
                if e.is_dir:
                    walk(full, base)
                else:
                    rel = _k(full.split(":", 1)[1])
                    out[rel] = (e.name, h(e.name, a.read_file(full)))
                    seen.add(rel)
        try:
            walk("SYS:" + td, td)
        except Exception:
            pass
    # single-file dests (placeFile/copyGlob/drawerIcon) not under a tree dest
    for k in exp_keys:
        if k in seen:
            continue
        try:
            data = a.read_file("SYS:" + k)
            out[k] = (os.path.basename(k), h(os.path.basename(k), data))
        except Exception:
            pass  # missing -> flagged by diff
    return out


def main():
    if len(sys.argv) != 6 or sys.argv[1] != "verify":
        print(__doc__); return 2
    _, _, host, catalog, pkgid, archive = sys.argv
    d = json.load(open(catalog)); pk = d["packages"] if isinstance(d, dict) else d
    entry = {x["id"]: x for x in pk}[pkgid]
    ops = entry["recipe"]["ops"]
    a = Amiga(host, token="a4000", timeout=60)
    def_drawer = a.read_file("ENVARC:Sys/def_drawer.info")
    # CPU class of the TARGET (mirrors amipkg's AttnFlags read): 2 = 68040/060,
    # 1 = 68020/030, 0 = 68000/010 — for cpuPlaceFile variant selection.
    cpu = str(a.system_info().get("cpu", "")).lower()
    cpu_class = 2 if ("68040" in cpu or "68060" in cpu) else (1 if ("68020" in cpu or "68030" in cpu) else 0)
    tmp, root = extract(archive)
    exp, tree_dests = {}, []
    try:
        files = list_files(root)
        for op in ops:
            k = op["op"]
            if k == "copyTree":    op_copy_tree(op, root, files, exp, tree_dests)
            elif k == "copyGlob":  op_copy_glob(op, root, files, exp)
            elif k == "placeFile": op_place_file(op, root, files, exp)
            elif k == "cpuPlaceFile": op_cpu_place_file(op, root, files, exp, cpu_class)
            elif k == "drawerIcon": op_drawer_icon(op, root, files, exp, def_drawer)
            else:
                print(f"  (oracle can't interpret op '{k}' yet)"); return 2
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    act = actual_for(a, set(exp), tree_dests)
    ek, ak = set(exp), set(act)
    missing, extra = sorted(ek - ak), sorted(ak - ek)
    changed = [k for k in (ek & ak) if exp[k][1] != act[k][1]]
    ok = not (missing or extra or changed)
    print(f"ORACLE {pkgid} ({os.path.basename(archive)}): "
          f"{'PASS ✅ byte-identical to archive+recipe' if ok else 'FAIL ❌'}  "
          f"({len(exp)} expected files, ops={[o['op'] for o in ops]})")
    for k in missing: print(f"  MISSING  {k}")
    for k in extra:   print(f"  EXTRA    {k}")
    for k in changed: print(f"  CHANGED  {k}  exp={exp[k][1][:12]} act={act[k][1][:12]}")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
