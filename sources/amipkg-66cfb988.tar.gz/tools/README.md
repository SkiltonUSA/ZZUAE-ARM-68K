# amipkg/tools

Host-side helpers for developing and **proving** amipkg recipes. None of these
run on the Amiga; they drive a networked agent (the amimcp `amiga.py` client) or
process the catalog on your Mac/Linux box.

## Faithfulness oracles — prove a recipe installs byte-identically

The contract (`PackageRecipeConverter`): an on-device `amipkg install` must
produce a tree **byte-identical** to what Amiga Imager's build engine installs.
These oracles prove it against the pinned archive — no live host-build snapshot,
so they are immune to Workbench icon mutation and catalog-vs-image version skew.

- **`recipe_oracle.py`** — the general one. Reads a package's recipe from the
  signed catalog, extracts the pinned `.lha` (`unar -D`, archive-native layout =
  amipkg's on-Amiga `lha` extractor), interprets each op the way `arun.c`
  plan_tree/plan_copy/plan_cpu do, and diffs an actual on-device install against
  the expected tree. Handles `copyTree`, `copyGlob`, `placeFile`, `cpuPlaceFile`
  (CPU class read from the target's `system_info`), and `drawerIcon`.

  ```
  python3 tools/recipe_oracle.py verify <host> <catalog.json> <pkgid> <archive.lha>
  # e.g. verify 192.168.178.33 ../amiga-pkg/docs/packages.json amissl AmiSSL-5.27-OS3.lha
  ```

- **`simpleapp_oracle.py`** — the specialised copyTree+drawerIcon form (the
  simple-app installer). `verify <host> <archive.lha> <appName> <destPath>`.

- **`golden.py`** — the older live-capture harness (`capture`/`verify` a running
  image's installed tree). Superseded by the archive oracles for anything that
  ships CPU-variant builds or that Workbench may have re-iconed; kept for
  whole-image spot checks. Normalises `.info` icon position (do_CurrentX/Y).

Icon `.info` files are compared with the runtime-mutable position field masked;
copyTree destinations are treated as authoritative (extras are flagged), while
`placeFile`/`cpuPlaceFile` single-file dests (Libs:/Prefs:/C:) are not walked for
extras since they land among unrelated system files.

## `amipkg-repo-sign`

Ed25519-sign a `packages.json` for a self-hosted repository (see `HOSTING.md`).
The catalog for the official repo is signed by `amiga-pkg`'s
`scripts/refresh-and-publish.sh`; use this only for your own mirror.
